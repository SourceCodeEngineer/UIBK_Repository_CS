SELECT      category.name AS Category,
            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 1) AS Monday,
            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 2) AS Tuesday,
            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 3) AS Wednesday,
            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 4) AS Thursday,
            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 5) AS Friday,
            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 6) AS Saturday,
            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 7) AS Sunday,
            COUNT(*) Total
FROM        rental
INNER JOIN  inventory
ON          rental.inventory_id = inventory.inventory_id
INNER JOIN  film_category 
ON          inventory.film_id = film_category.film_id
INNER JOIN  category 
ON          film_category.category_id = category.category_id
WHERE       rental.rental_date BETWEEN '2005-01-01' AND '2005-12-31'
GROUP BY    category.name
ORDER BY    category.name
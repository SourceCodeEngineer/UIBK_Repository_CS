SELECT      customer.customer_id, customer.first_name, customer.last_name
FROM        customer
INNER JOIN  payment
ON          customer.customer_id = payment.customer_id
GROUP BY    customer.customer_id, customer.first_name, customer.last_name
HAVING      SUM(payment.amount) > (
    SELECT      AVG(sum_amount) AS avg_amount
    FROM (
        SELECT      customer_id, SUM(amount) AS sum_amount
        FROM        payment
        GROUP BY    customer_id
    ) v
)
SELECT			customer.customer_id,
				customer.first_name,
				customer.last_name,
				(
					SELECT 	SUM(payment.amount) AS total_amount
					FROM	payment
					WHERE	payment.customer_id = customer.customer_id
				) AS total_amount
FROM			customer

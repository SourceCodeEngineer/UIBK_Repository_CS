SELECT		film.rating,
			SUM(film.rental_rate) / COUNT(*) AS average_rate
FROM		film
GROUP BY	film.rating
HAVING 		SUM(film.rental_rate) / COUNT(*) >= 3.0

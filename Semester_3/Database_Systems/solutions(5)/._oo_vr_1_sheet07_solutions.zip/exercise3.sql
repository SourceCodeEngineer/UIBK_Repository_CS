SELECT      *
FROM (
    SELECT		customer.customer_id,
                customer.first_name,
                customer.last_name,
                SUM(payment.amount) AS total_amount
    FROM		payment
    INNER JOIN	customer
    ON		    payment.customer_id = customer.customer_id
    GROUP BY	customer.customer_id,
                customer.first_name,
                customer.last_name
        
    UNION ALL

    SELECT		0,
                'Summe',
                '',
                SUM(payment.amount) AS total_amount
    FROM		payment
) v
ORDER BY    4
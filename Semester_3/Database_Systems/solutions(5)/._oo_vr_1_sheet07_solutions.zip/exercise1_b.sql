SELECT		film.film_id,
			film.title,
			COUNT(rental.customer_id) AS simple_count,
			COUNT(DISTINCT rental.customer_id) AS distinct_count	
FROM		rental
INNER JOIN	inventory
ON			rental.inventory_id = inventory.inventory_id
INNER JOIN	film
ON			inventory.film_id = film.film_id
GROUP BY	film.film_id,
			film.title

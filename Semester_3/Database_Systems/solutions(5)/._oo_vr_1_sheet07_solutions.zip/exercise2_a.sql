SELECT			actor.first_name,
				actor.last_name
FROM			actor
WHERE			actor_id IN (
	SELECT			actor_id
	FROM			film_actor
	INNER JOIN		film
	ON				film_actor.film_id = film.film_id
	WHERE			film.title = 'SUNSET RACER'
)

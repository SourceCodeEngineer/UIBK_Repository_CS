select * 
from pg_database;

public class Fibonacci {
  public static void main(String[] args) {
    int counter = 0;
    int fib0 = 1;
    int fib1 = 1;
    while (counter < 10) {
      System.out.println(fib0);
      int tmp = fib0 + fib1;
      fib0 = fib1;
      fib1 = tmp;
      counter++;
    }
  }
}

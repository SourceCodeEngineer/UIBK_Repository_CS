/**
 * This class is used for calculating a possible discount for a shopping cart.
 */
public class ShoppingCartSolution {

  /**
   * Main method of the program.
   *
   * @param args command line arguments.
   */
  public static void main(final String[] args) {

    // list of product prices in shopping cart as a Java array

    // shopping cart 1
    double[] shoppingCart1 =
        new double[] {40.95, 10.80, 2.35, 22.50, 13.45, 5.95, 33.33, 41.10, 7.75, 5};

    // shopping cart 2
    double[] shoppingCart2 = new double[] {40.95, 10.80, 2.35, 22.50, 13.45, 5.95, 33.33,
        41.10, 7.75, 5, 1.25, 10.40, 6.10, 14.40, 55.55};

    // shopping cart 3
    double[] shoppingCart3 = new double[] {40.95, 10.80, 2.35, 22.50, 13.45, 5.95, 33.33,
        41.10, 7.75, 5, 1.25, 10.40, 6.10, 14.40, 55.55, 4.35, 2.02, 45.67, 35.34, 345.46, 34.30,
        66.30, 4.23, 1.23, 5.77, 85.89};

    // shopping cart 4
    int[] shoppingCart4 = new int[] {40, 10, 2, 22, 13, 5, 33, 41, 7, 5};

    // TODO: test for all 4 carts
    double[] currentCart = shoppingCart1;

    int numberOfItems = currentCart.length;
    double originalPrice = totalPrice(currentCart);
    double discountedPrice = calculateDiscountedPrice(originalPrice, numberOfItems);

    // ******OUTPUT on console:******
    System.out.println(" Original price:   " + originalPrice);
    System.out.println(" Discounted price: " + discountedPrice);
  }

  /**
   * Calculates the discounted price for a shopping cart based on the number of items in the
   * cart and the discount amount.
   *
   * @param originalPrice the price of the cart without discount.
   * @param numberOfItems the number of items in the cart.
   *
   * @return The disconted price of the shopping cart.
   */
  private static double calculateDiscountedPrice(final double originalPrice, final int numberOfItems) {
    double discountAmount = calculateDiscount(originalPrice);
    double discount = 0.0d;

    switch (numberOfItems) {
      case 5:
        discount = (originalPrice * discountAmount) / 100;
        break;
      case 10:
        discount = (originalPrice * discountAmount) / 100 + 10;
        break;
      case 15:
        discount = (originalPrice * discountAmount) / 100 + 15;
        break;
      case 20:
        discount = (originalPrice * discountAmount) / 100 + 20;
        break;
      case 25:
        discount = (originalPrice * discountAmount) / 100 + 25;
        break;
      case 30:
        discount = (originalPrice * discountAmount) / 100 + 30;
        break;

      default:
        return originalPrice;
    }

    return Math.round((originalPrice - discount) * 100) / 100.0d;
  }

  /**
   * Calculates the discount amount depending on original price of the cart.
   *
   * @param originalPrice the original total price of a cart.
   *
   * @return The discount that one gets on the original price.
   */
  private static double calculateDiscount(final double originalPrice) {
    if (originalPrice < 50) {
      return 0;
    }
    if (originalPrice >= 50 && originalPrice < 60) {
      return 5;
    }

    if (originalPrice >= 60 && originalPrice < 70) {
      return 10;
    }

    if (originalPrice >= 70 && originalPrice < 100) {
      return 15;
    }

    if (originalPrice >= 100) {
      return 20;
    }
    return 0;
  }


  /**
   * Calculates the total price of all product contained in a cart.
   *
   * @param cart the shopping cart to calculate the price for.
   *
   * @return The summ of all prices in a cart.
   */
  private static double totalPrice(final double[] cart) {
    double sum = 0.0;
    for (double price : cart) {
      sum += price;
    }

    return Math.round(sum * 100) / 100.0d;
  }
}

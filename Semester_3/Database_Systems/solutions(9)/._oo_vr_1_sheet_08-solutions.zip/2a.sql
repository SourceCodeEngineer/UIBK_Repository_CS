CREATE TABLE nation (
    nation_id int PRIMARY KEY,
    name varchar(64) NOT NULL,
    flag bytea NULL
);

CREATE TABLE team (
    team_id int PRIMARY KEY,
    name varchar(64) NOT NULL,
    starts_for int NOT NULL,
    CONSTRAINT fk_team_nation FOREIGN KEY (starts_for) REFERENCES nation (nation_id)
);

CREATE TABLE athlete (
    athlete_id int PRIMARY KEY,
    name varchar(64) NOT NULL,
    age int NOT NULL
);

CREATE TABLE "event" (
    event_id int PRIMARY KEY,
    title varchar(64) NOT NULL,
    "date" date NOT NULL,
    is_team_event boolean NOT NULL
);

CREATE TABLE athlete_in_team (
    athlete_id int NOT NULL,
    team_id int NOT NULL,
    CONSTRAINT fk_athlete_in_team_athlete FOREIGN KEY (athlete_id) REFERENCES athlete (athlete_id),
    CONSTRAINT fk_athlete_in_team_team FOREIGN KEY (team_id) REFERENCES team (team_id)
);

CREATE TABLE athlete_participates_in_event (
    athlete_id int NOT NULL,
    event_id int NOT NULL,
    rank int NOT NULL,
    CONSTRAINT fk_athlete_participates_in_event_athlete FOREIGN KEY (athlete_id) REFERENCES athlete (athlete_id),
    CONSTRAINT fk_athlete_participates_in_event_event FOREIGN KEY (event_id) REFERENCES "event" (event_id)
);

CREATE TABLE team_participates_in_event (
    team_id int NOT NULL,
    event_id int NOT NULL,
    rank int NOT NULL,
    CONSTRAINT fk_team_participates_in_event_team FOREIGN KEY (team_id) REFERENCES team (team_id),
    CONSTRAINT fk_athlete_participates_in_event_event FOREIGN KEY (event_id) REFERENCES "event" (event_id)
);

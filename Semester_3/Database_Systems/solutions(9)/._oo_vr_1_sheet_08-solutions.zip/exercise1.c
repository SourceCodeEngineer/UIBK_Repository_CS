#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#include <libpq-fe.h>

PGconn* open_connection() {
    const char* connection_parameters[] = { "host",      "dbname", "user",      "password", 0 };
    const char* connection_values[] =     { "localhost", "pagila", "postgres",  "postgres", 0 };

    PGconn* connection = PQconnectdbParams(connection_parameters, connection_values, 0);

    if (PQstatus(connection) != CONNECTION_OK) {
        return NULL;
    }

    return connection;
}

char* read_input() {
    // Read input line from stdin.
    char* input = NULL;
    size_t len = 0;
    size_t n_read = getline(&input, &len, stdin);

    if (n_read == -1) {
        printf("ERROR: Could not read user input.\n");
        exit(EXIT_FAILURE);
    }

    // Remove newline at the end.
    input[n_read - 1] = '\0';

    // Done.
    return input;
}

void make_rental_report(PGconn* connection, const char* query) {
    // Ask the user for the date range.
    printf("From: ");
    char* from = read_input();

    printf("To: ");
    char* to = read_input();

    // Execute parametrized statement.
    const Oid parameter_types[] = { 1082, 1082 };
    const char* parameters[] = { from, to };

    PGresult* result = PQexecParams(
        connection,
        query,
        2,
        parameter_types,
        parameters,
        NULL,
        NULL,
        0
    );

    if (PQresultStatus(result) != PGRES_TUPLES_OK) {
        printf("ERROR: Error executing the query.\n");
        printf("%s", PQerrorMessage(connection));

        free(from);
        free(to);
        PQclear(result);
        return;
    }

    // Print result.
    int n_rows = PQntuples(result);

    printf("category_name       | mon | tue | wed | thu | fri | sat | sun | total\n");
    printf("---------------------------------------------------------------------\n");

    for (int i = 0; i < n_rows; i++) {
        char* category_name = PQgetvalue(result, i, 0);
        char* mon = PQgetvalue(result, i, 1);
        char* tue = PQgetvalue(result, i, 2);
        char* wed = PQgetvalue(result, i, 3);
        char* thu = PQgetvalue(result, i, 4);
        char* fri = PQgetvalue(result, i, 5);
        char* sat = PQgetvalue(result, i, 6);
        char* sun = PQgetvalue(result, i, 7);
        char* total = PQgetvalue(result, i, 8);

        printf("%-19s | %3s | %3s | %3s | %3s | %3s | %3s | %3s | %s\n", category_name, mon, tue, wed, thu, fri, sat, sun, total);
    }

    // Clean up.
    free(from);
    free(to);
    PQclear(result);
}

void run_rental_report(PGconn* connection) {
    // Generate the report using a direct query.
    make_rental_report(
        connection,
        "SELECT      category.name AS category_name,\n"
        "            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 1) AS mon,\n"
        "            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 2) AS tue,\n"
        "            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 3) AS wed,\n"
        "            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 4) AS thu,\n"
        "            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 5) AS fri,\n"
        "            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 6) AS sat,\n"
        "            COUNT(*) FILTER (WHERE EXTRACT(ISODOW FROM rental.rental_date) = 7) AS sun,\n"
        "            COUNT(*) AS total\n"
        "FROM        rental\n"
        "INNER JOIN  inventory\n"
        "ON          rental.inventory_id = inventory.inventory_id\n"
        "INNER JOIN  film_category\n"
        "ON          inventory.film_id = film_category.film_id\n"
        "INNER JOIN  category\n"
        "ON          film_category.category_id = category.category_id\n"
        "WHERE       rental.rental_date::date BETWEEN $1 AND $2\n"
        "GROUP BY    category.name\n"
        "ORDER BY    category.name"
    );
}

void run_rental_report_function(PGconn* connection) {
    // Generate the report using a table function.
    make_rental_report(
        connection,
        "SELECT * FROM report_function($1, $2);"
    );
}

int main(void) {
    // Open a connection to the database.
    PGconn* connection = open_connection();

    if (!connection) {
        printf("ERROR: Could not connect to the database.\n");

        PQfinish(connection);
        return EXIT_FAILURE;
    }

    // Provide the user with a command prompt and handle commands.
    printf("Welcome to Pagila Reports!\n\n");

    bool running = true;
    while (running) {
        // Print prompt.
        printf("(Pagila)> ");

        // Read user input.
        char* input = read_input();

        // Dispatch user commands.
        if (strcmp(input, "exit") == 0) {
            printf("Bye!\n");
            running = false;
        }
        else if (strcmp(input, "rental_report") == 0) {
            run_rental_report(connection);
        }
        else if (strcmp(input, "rental_report_function") == 0) {
            run_rental_report(connection);
        }

        // Free the input string.
        free(input);
    }

    // Done.
    PQfinish(connection);
    return EXIT_SUCCESS;
}

CREATE FUNCTION check_team_size()
RETURNS TRIGGER 
AS $$
    DECLARE num_athletes int;
    BEGIN
        -- Get the number of athletes for the given team.
        SELECT INTO num_athletes COUNT(*)
        FROM        athlete_in_team
        WHERE       team_id = NEW.team_id;

        -- Check condition.
        IF num_athletes > 20 THEN
            RAISE EXCEPTION 'Teams can not consist of more than 20 athletes!';
        END IF;

        -- Done, all good.
        RETURN NEW;
    END
$$ LANGUAGE plpgsql;



CREATE TRIGGER      trigger_check_team_size
AFTER INSERT ON     athlete_in_team
FOR EACH ROW
EXECUTE PROCEDURE   check_team_size();

INSERT INTO nation (nation_id, name)
VALUES      (0, 'Austria');

INSERT INTO team (team_id, name, starts_for)
VALUES      (0, 'Test team', 0);

INSERT INTO athlete (athlete_id, name, age)
VALUES      (0, 'Test Athlete', 25),
            (1, 'Test Athlete', 25),
            (2, 'Test Athlete', 25),
            (3, 'Test Athlete', 25),
            (4, 'Test Athlete', 25),
            (5, 'Test Athlete', 25),
            (6, 'Test Athlete', 25),
            (7, 'Test Athlete', 25),
            (8, 'Test Athlete', 25),
            (9, 'Test Athlete', 25),
            (10, 'Test Athlete', 25),
            (11, 'Test Athlete', 25),
            (12, 'Test Athlete', 25),
            (13, 'Test Athlete', 25),
            (14, 'Test Athlete', 25),
            (15, 'Test Athlete', 25),
            (16, 'Test Athlete', 25),
            (17, 'Test Athlete', 25),
            (18, 'Test Athlete', 25),
            (19, 'Test Athlete', 25),
            (20, 'Test Athlete', 25);

INSERT INTO athlete_in_team (athlete_id, team_id)
VALUES      (0, 0),
            (1, 0),
            (2, 0),
            (3, 0),
            (4, 0),
            (5, 0),
            (6, 0),
            (7, 0),
            (8, 0),
            (9, 0),
            (10, 0),
            (11, 0),
            (12, 0),
            (13, 0),
            (14, 0),
            (15, 0),
            (16, 0),
            (17, 0),
            (18, 0),
            (19, 0),
            (20, 0);

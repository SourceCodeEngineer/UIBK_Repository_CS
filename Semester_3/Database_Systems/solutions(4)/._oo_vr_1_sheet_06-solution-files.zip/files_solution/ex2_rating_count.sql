SELECT          COUNT(DISTINCT film.rating) AS different_ratings
FROM            film
INNER JOIN      language
ON              film.language_id = language.language_id
WHERE           language.name = 'English'
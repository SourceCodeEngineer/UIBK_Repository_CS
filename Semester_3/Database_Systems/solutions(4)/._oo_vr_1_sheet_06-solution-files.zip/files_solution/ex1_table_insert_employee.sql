INSERT INTO working (employee_id, project_id, start_date)
VALUES (
  (SELECT employee_id FROM employee 
    WHERE firstname = 'Max' AND lastname = 'Mustermann'),
  (SELECT project_id FROM project WHERE name = 'project2'),
  DATE('2019-02-02')
);

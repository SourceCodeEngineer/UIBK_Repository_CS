CREATE TABLE project (
  project_id SERIAL PRIMARY KEY,
  name VARCHAR(255),
  country VARCHAR(255)
);

CREATE TABLE employee (
  employee_id SERIAL PRIMARY KEY,
  firstname VARCHAR(255),
  lastname VARCHAR(255),
  country VARCHAR(255)
);

CREATE TABLE working (
  employee_id INT NOT NULL REFERENCES employee(employee_id),
  project_id INT NOT NULL REFERENCES project(project_id),
  start_date TIMESTAMP
);


SELECT          customer.first_name,
                customer.last_name
FROM            customer
INNER JOIN      rental
ON              customer.customer_id = rental.customer_id
INNER JOIN      staff
ON              rental.staff_id = staff.staff_id
WHERE           staff.username = 'Mike'
AND             DATE(rental.rental_date) = '2005-06-14'
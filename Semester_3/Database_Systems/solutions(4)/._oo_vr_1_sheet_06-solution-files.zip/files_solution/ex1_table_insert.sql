INSERT INTO employee (firstname, lastname, country) 
VALUES
  ('Donald', 'Duck', 'USA'),
  ('Max', 'Mustermann', 'Austria'),
  ('Benjamin', 'Murauer', 'Austria');

INSERT INTO project (name, country) 
VALUES
  ('project1', 'USA'),
  ('project2', 'Germany'),
  ('project3', 'Austria');

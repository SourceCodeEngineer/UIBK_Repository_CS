SELECT          title,
                release_year
FROM            actor
INNER JOIN      film_actor
ON              actor.actor_id = film_actor.actor_id
INNER JOIN      film
ON              film_actor.film_id = film.film_id
WHERE           actor.last_name = 'CAGE'
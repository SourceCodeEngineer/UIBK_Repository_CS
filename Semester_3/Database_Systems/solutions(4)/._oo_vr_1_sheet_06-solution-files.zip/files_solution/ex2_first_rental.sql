SELECT          customer.first_name,
                customer.last_name,
                staff.first_name,
                staff.last_name
FROM            customer
INNER JOIN      rental
ON              customer.customer_id = rental.customer_id
INNER JOIN      staff
ON              rental.staff_id = staff.staff_id
ORDER BY        rental.rental_date ASC
FETCH           FIRST 1 ROWS ONLY
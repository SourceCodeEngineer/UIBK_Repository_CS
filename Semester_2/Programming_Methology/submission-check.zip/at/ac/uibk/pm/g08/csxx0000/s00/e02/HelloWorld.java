package at.ac.uibk.pm.g08.csxx0000.s00.e02;

public class HelloWorld {
	public static void main(String[] args) {
		// Prints "Hello World!" to the terminal window.
		System.out.println("Hello World!");
	}
}

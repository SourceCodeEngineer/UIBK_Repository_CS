int doubles(int x)
{
	return (x * 2);
}

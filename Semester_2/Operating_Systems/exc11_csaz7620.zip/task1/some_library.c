int square_my_integer(int x) {
	return (x * x);
}
